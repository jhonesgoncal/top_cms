<?php
include "../banco/conecta.php";
  $titulo = addslashes($_POST['titulo']);
  $subTitulo = addslashes($_POST['subTitulo']);
  $corpo = addslashes($_POST['editor']);
  $id = addslashes($_POST['id']);
  $publicado = addslashes($_POST['publicado']);

  $sql = "UPDATE noticias SET titulo = '{$titulo}',, publicado='{$publicado}' subTitulo='{$subTitulo}', corpo='{$corpo}' WHERE id='{$id}'";

  $retorno = mysqli_query($conecta, $sql);

  var_dump($sql);
  var_dump($retorno);

?>